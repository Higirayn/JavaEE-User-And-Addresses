package com.example.demo1.ejb;

import com.example.demo1.model.Address;
import com.example.demo1.model.Client;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import java.util.Collections;
import java.util.Date;

@Stateless
public class UpdateBean {

    @PersistenceContext(unitName = "ClientPU")
    private EntityManager em;

    public void createClient(String name, String type, String ip, String mac, String model, String addressText) {
        Client client = new Client();
        client.setClient_name(name);
        client.setType(type);
        client.setAdded(new Date());

        Address address = new Address();
        address.setIp(ip);
        address.setMac(mac);
        address.setModel(model);
        address.setAddress(addressText);
        address.setClient(client);

        client.setAddresses(Collections.singletonList(address));

        em.persist(client);
    }

    public void updateClient(int id, String name, String type /* и другие поля */) {
        Client client = em.find(Client.class, id);
        if (client != null) {
            client.setClient_name(name);
            client.setType(type);
            // обновить остальные поля
            em.merge(client);
        }
    }

    public void deleteClient(int id) {
        Client client = em.find(Client.class, id);
        if (client != null) {
            em.remove(client);
        }
    }

    public Client findClientById(int id) {
        return em.find(Client.class, id);
    }

    // Аналогично: updateClient, deleteClient ...
}